//
//  DiceRollerApp.swift
//  DiceRoller
//
//  Created by Meezotech Mac on 01/01/2026.
//

import SwiftUI

@main
struct DiceRollerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
