//
//  OnboardingFLowPracApp.swift
//  OnboardingFLowPrac
//
//  Created by Meezotech Mac on 25/11/2025.
//

import SwiftUI

@main
struct OnboardingFLowPracApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
