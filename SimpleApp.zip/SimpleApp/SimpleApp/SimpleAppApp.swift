//
//  SimpleAppApp.swift
//  SimpleApp
//
//  Created by Meezotech Mac on 02/01/2026.
//

import SwiftUI

@main
struct SimpleAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
