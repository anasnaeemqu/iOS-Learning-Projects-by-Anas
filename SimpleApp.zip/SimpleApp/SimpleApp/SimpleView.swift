//
//  SimpleView.swift
//  SimpleApp
//
//  Created by Meezotech Mac on 02/01/2026.
//

import SwiftUI

struct SimpleView: View {
    let description: String
    @Binding var isVisible: Bool
    
    var body: some View {
        
        ZStack(alignment: .topLeading){
            
            RoundedRectangle(cornerRadius: 12)
                .foregroundStyle(.buttoncolor)
                .opacity(0.25)
                .brightness(-0.4)
            VStack(alignment: .leading, spacing: 10){
                
//                Image(systemName: "xmark.circle.fill")
//                    .foregroundStyle(.white)
//                    .padding([.top, .leading], 8)
                Button(action: {
                    withAnimation {
                 isVisible = false
                                    }
                }) { Image(systemName: "xmark.circle.fill") }
                    .foregroundStyle(.white)
                    .padding([.top, .leading], 8)
                
                Text(description)
                    .font(.title)
                    .padding()
                    .foregroundStyle(.white)
            }
            
        }
        .padding()
        .frame(maxWidth: 500, maxHeight: 300)
        Spacer()
    }
}

#Preview {
    SimpleView(description: "A multiline description about a feature paired with the image on the left.", isVisible: .constant(true))
}

