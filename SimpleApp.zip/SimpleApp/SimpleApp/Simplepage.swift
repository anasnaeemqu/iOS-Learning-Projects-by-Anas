//
//  Simplepage.swift
//  SimpleApp
//
//  Created by Meezotech Mac on 03/01/2026.
//

import SwiftUI

struct Simplepage: View {
    @State private var showCard: Bool = false
    @State private var descriptionText: String = ""
    var body: some View {
        VStack{
            Text("Tap to Read")
                .font((.title))
                .fontWeight(.bold)
            HStack(spacing: 20){
                Button("Grateful") {
                    descriptionText = "I'm loved and appreciated"
                    withAnimation {
                        showCard = true
                    }
                }
                .buttonStyle(.bordered)
//                .background(.buttoncolor)

                Button("Excited") {
                    descriptionText = "I radiate joy and happiness wherever I go"
                    withAnimation {
                        showCard = true
                    }
                }
                .buttonStyle(.bordered)
//                .background(.buttoncolor)
                
                Button("Happy") {
                    descriptionText = "I am confident in who I am"
                    withAnimation {
                        showCard = true
                    }
                }
                .buttonStyle(.bordered)
            }
            if showCard {
                SimpleView(description: descriptionText, isVisible: $showCard)
                    .transition(.scale)
                    .padding()
            }
        }
        .tint(.black)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(.appbackground)
    }
}
    #Preview {
        Simplepage()
    }
