//
//  new_yearApp.swift
//  new-year
//
//  Created by Meezotech Mac on 31/12/2025.
//

import SwiftUI

@main
struct new_yearApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
